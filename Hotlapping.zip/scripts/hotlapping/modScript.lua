-- modScript.lua
log('I', 'modScript', 'Hotlapping mod loading...')
log('I', 'modScript', 'Hotlapping mod loaded successfully')
